/* WORD LADDER Main.java
 * EE422C Project 3 submission by
 * Replace <...> with your actual data.
 * Danny Vo
 * dpv292
 * <Student1 5-digit Unique No.>
 * James Tsao
 * jt28593
 * <Student2 5-digit Unique No.>
 * Slip days used: <0>
 * Summer 2016
 */
 
 In main: debug true runs junit tests.
          debug false allows for normal operation of the WordLadder game.
          
          bfs true runs the bfs version
          dfs true runs the dfs version